// ======== TASK 3 ========

#include <stdio.h>
#include <math.h>
int main() {
    int n,k;
    double s,f;
    printf("Enter the number of terms to be used from Taylor series: ");
    scanf("%d",&n);
    printf("Enter the number of divisions in [0,2pi]: ");
    scanf("%d",&k);
    printf("\n\nEvaluating cos(x) with n=%d terms of the Taylor series at (k+1)=%d points in [0,2pi]:\n",n,k+1);
    for (int i=0;i<=k;i++) {
        s=f=1.0d;
        double x=(double)(i*i*4)*3.141592653589793d*3.141592653589793d/(double)(k*k);
		double xterm=x;
        for (int j=1;j<n;j++) {
            f*=2*j*(2*j-1);    // f in each iteration is (2j)!
            s+=pow(-1,j)*xterm/f;
            xterm*=x; }
        printf("\nx = %.15lf rad (%.3fpi) -> cos(x) = %.15lf",x,(float)i*2/k,s); }
	printf("\n");
    return 0; }

// NOTE: TO GET BETTER ACCURACY IN RESULTS OF COS(X) WITH VALUES OF X CLOSER TO 2PI, USE HIGHER VALUES OF N. LOWER VALUES OF N MAY DIVERGE THE SERIES AND SHOW INACCURATE RESULTS. FOR EXAMPLE, THE SERIES STARTS BECOMING FAIRLY ACCURATE FROM N = 9 (FOR K=4).



// ======== TASK 4 ========

#include <stdio.h>
int main()
{
int A,B,temp;
printf("Enter two positive integers A and B: ");
scanf("%d %d", &A,&B);
if (A>B) { temp=B; B=A; A=temp; }
if (A<=1) A=2;
if (B>1) {
	printf("\nPrimes numbers in range [A,B] are:\n\n");
	int isPrime=1;
	for (int i=A;i<=B;i++) {
		isPrime=1;
		for (int j=2;j<i;j++) {
			if (i%j==0) { isPrime=0; break; } }
		if (isPrime==1) printf("%d\n",i); } }
else printf("Invalid input. Positive integers needed.");
return 0;
}



// ======== TASK 5 ========

#include <stdio.h>
int main()
{
int size,evenCount=0,oddCount=0;
printf("Enter the size of the array: ");
scanf("%d", &size);
int array[size];
printf("Enter integers one-by-one: \n");
for (int i=0;i<size;i++) {
	scanf("%d",&array[i]); 
	if (array[i]%2==0) evenCount+=1;
	else oddCount+=1; }
int even[evenCount],odd[oddCount];
evenCount=oddCount=0;
for (int i=0;i<size;i++) {
	if (array[i]%2==0) { even[evenCount]=array[i]; evenCount+=1;}
	else { odd[oddCount]=array[i]; oddCount+=1; } }
printf("Even numbers are: ");
for (int i=0;i<evenCount;i++) { printf("%d ",even[i]); }
printf("Odd numbers are: ");
for (int i=0;i<oddCount;i++) { printf("%d ",odd[i]); }
return 0;
}



// ======== TASK 6 ========

#include <stdio.h>
int main()
{
int size;
printf("Enter the size of the array: ");
scanf("%d", &size);
int count,array[size],countedOrNot[size];
for (int i=0;i<size;i++) countedOrNot[i]=0;
printf("Enter the values of the array:\n");
for (int i=0;i<size;i++) scanf("%d",&array[i]);
for (int i=0;i<size;i++) {
	count=0;
	if (countedOrNot[i]==1) continue;
	for (int j=i;j<size;j++) {
		if (array[i]==array[j]) {
			count++;
			countedOrNot[j]=1; } }
	printf("%d occurs %d time(s)\n",array[i],count); }
return 0;
}
