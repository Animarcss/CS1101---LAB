#include <stdio.h>
#include <stdlib.h>

struct lib {
	char bookName[50];
	char bookAuthor[50];
	short bookID; };

// 'struct lib' acts as a new user-defined data type for a variable.

void sortID(struct lib books[],struct lib sorted[],int n) {

int main() {
	struct lib a="Pride and Prejudice","Jane Austen",1;
	struct lib b="The Great Gatsby","F. Scott Fitzgerald",2;
	struct lib c="Lord of the Flies","William Golding",3;
	struct lib d="Don Quixote","Miquel de Cervantes",4;
	struct lib e="The Adventures of Huckleberry Finn","Mark Twain",5;
	struct lib f="Alice's Adventures in Wonderland","Lewis Carroll",6;
	struct lib g="A Tale of Two Cities","Charles Dickens",7;
	struct lib h="Train to Pakistan","Khushwant Singh",8;
	struct lib i="The White Tiger","Aravind Adiga",9;
	struct lib j="The Guide","R.K. Narayan",10;
	
	struct lib books[]={a,b,c,d,e,f,g,h,i,j};
